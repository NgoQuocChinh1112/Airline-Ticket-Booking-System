package com.example.flightbooking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightbookingApplicationTests {

	@Test
	void contextLoads() {
	}

}
